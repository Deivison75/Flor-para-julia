import { useEffect, useState } from "react";
import type { CSSProperties } from "react";

const sparkles = [
  { x: 8, y: 17, size: 4, delay: 0.8 },
  { x: 17, y: 70, size: 2, delay: 1.8 },
  { x: 28, y: 25, size: 3, delay: 2.6 },
  { x: 39, y: 77, size: 2, delay: 1.2 },
  { x: 52, y: 12, size: 3, delay: 3.4 },
  { x: 68, y: 25, size: 2, delay: 1.5 },
  { x: 76, y: 74, size: 4, delay: 2.2 },
  { x: 87, y: 15, size: 2, delay: 0.4 },
  { x: 92, y: 53, size: 3, delay: 2.9 },
  { x: 58, y: 88, size: 2, delay: 1.9 },
];

type FallingPetal = {
  id: number;
  left: number;
  size: number;
  duration: number;
  drift: number;
  rotate: number;
  opacity: number;
};

const petalPath = "M 50 4 C 28 10 14 31 17 49 C 20 67 38 82 50 96 C 62 82 80 67 83 49 C 86 31 72 10 50 4 Z";

export default function Home() {
  const [bloomComplete, setBloomComplete] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const [ctaPresent, setCtaPresent] = useState(true);
  const [fallingPetals, setFallingPetals] = useState<FallingPetal[]>([]);

  useEffect(() => {
    const bloomTimer = window.setTimeout(() => setBloomComplete(true), 4700);
    return () => window.clearTimeout(bloomTimer);
  }, []);

  useEffect(() => {
    if (!revealed) return;

    let nextId = 0;
    const createPetal = () => {
      const petal: FallingPetal = {
        id: nextId++,
        left: Math.random() * 100,
        size: 10 + Math.random() * 18,
        duration: 6.5 + Math.random() * 4,
        drift: -120 + Math.random() * 240,
        rotate: -180 + Math.random() * 360,
        opacity: 0.35 + Math.random() * 0.5,
      };

      setFallingPetals((current) => [...current.slice(-54), petal]);
      window.setTimeout(() => {
        setFallingPetals((current) => current.filter((item) => item.id !== petal.id));
      }, petal.duration * 1000 + 500);
    };

    createPetal();
    const petalTimer = window.setInterval(createPetal, 320);
    return () => window.clearInterval(petalTimer);
  }, [revealed]);

  const revealLetter = () => {
    if (revealed) return;
    setRevealed(true);
    window.setTimeout(() => setCtaPresent(false), 580);
  };

  return (
    <main className={`love-page ${bloomComplete ? "bloom-complete" : ""} ${revealed ? "revealed" : ""}`}>
      <div className="ambient-glow ambient-glow-one" />
      <div className="ambient-glow ambient-glow-two" />

      <div className="sparkle-field" aria-hidden="true">
        {sparkles.map((sparkle, index) => (
          <span
            className="sparkle"
            key={index}
            style={
              {
                "--x": `${sparkle.x}%`,
                "--y": `${sparkle.y}%`,
                "--size": `${sparkle.size}px`,
                "--delay": `${sparkle.delay}s`,
              } as CSSProperties
            }
          />
        ))}
      </div>

      {revealed && (
        <div className="falling-petals" aria-hidden="true">
          {fallingPetals.map((petal) => (
            <span
              className="falling-petal"
              key={petal.id}
              style={
                {
                  "--left": `${petal.left}%`,
                  "--size": `${petal.size}px`,
                  "--duration": `${petal.duration}s`,
                  "--drift": `${petal.drift}px`,
                  "--rotate": `${petal.rotate}deg`,
                  "--opacity": petal.opacity,
                } as CSSProperties
              }
            >
              <svg viewBox="0 0 100 100" focusable="false">
                <path d={petalPath} />
              </svg>
            </span>
          ))}
        </div>
      )}

      <header className="site-header">
          <div className="brand-mark">
          <span className="brand-symbol">✦</span>
          <span>uma carta de amor</span>
        </div>
        <div className="header-note">
          <span className="live-dot" />
          <span>feito com ternura</span>
        </div>
      </header>

      <section className="love-layout" aria-label="Uma carta de amor">
        <div className="copy-column">
          <div className="eyebrow">
            <span className="eyebrow-line" />
            <span>para a pessoa mais especial</span>
          </div>

          <div className="message-stack">
            <div className={`message-layer initial-message ${revealed ? "is-replaced" : ""}`}>
              <p className="message-kicker">Uma pequena declaração</p>
              <h1>
                Para você, <em>meu amor</em> <span className="title-flower" aria-hidden="true">✿</span>
              </h1>
              <p className="message-subtitle">
                Algumas coisas ficam mais bonitas quando têm tempo para florescer... E o meu amor por você é uma delas.
              </p>
              {ctaPresent && (
                <button className="love-button" type="button" onClick={revealLetter}>
                  <span>Clica aqui</span>
                  <span className="button-heart" aria-hidden="true">♥</span>
                  <span className="button-arrow" aria-hidden="true">↗</span>
                </button>
              )}
            </div>

            <div className={`message-layer reveal-message ${revealed ? "is-active" : ""}`} aria-live="polite">
              <p className="message-kicker">a minha verdade mais bonita</p>
              <h2>Eu te amo! <span aria-hidden="true">♥</span></h2>
              <p className="message-subtitle">
                Você é a pessoa mais especial do meu mundo. Quero continuar cultivando este amor com você todos os dias. <span aria-hidden="true">🌸</span>
              </p>
              <div className="letter-signature">
                <span>com todo o meu coração</span>
                <span className="signature-heart" aria-hidden="true">♥</span>
              </div>
            </div>
          </div>

          <div className={`waiting-note ${bloomComplete ? "is-visible" : ""}`}>
            <span className="waiting-note-icon" aria-hidden="true">↓</span>
            <span>a beleza também sabe esperar</span>
          </div>
        </div>

        <div className="flower-column">
          <div className="flower-label flower-label-top">lírio laranja / 01</div>
          <div className={`flower-stage ${bloomComplete ? "is-complete" : ""}`}>
            <div className="flower-halo" />
            <div className="flower-ring flower-ring-one" />
            <div className="flower-ring flower-ring-two" />
            <svg className="flower-svg" viewBox="0 0 400 500" role="img" aria-labelledby="flower-title flower-description">
              <title id="flower-title">Um lírio laranja a desabrochar</title>
              <desc id="flower-description">Uma flor criada para representar um amor que cresce devagar e floresce por inteiro.</desc>
              <defs>
                <radialGradient id="petalGradient" cx="50%" cy="42%" r="68%">
                  <stop offset="0%" stopColor="#ffd66b" />
                  <stop offset="36%" stopColor="#ffae35" />
                  <stop offset="74%" stopColor="#ee642d" />
                  <stop offset="100%" stopColor="#a52e32" />
                </radialGradient>
                <linearGradient id="petalShade" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#fff0a4" stopOpacity="0.62" />
                  <stop offset="48%" stopColor="#ff9b2f" stopOpacity="0.18" />
                  <stop offset="100%" stopColor="#8d2639" stopOpacity="0.32" />
                </linearGradient>
                <linearGradient id="leafGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#567c58" />
                  <stop offset="42%" stopColor="#20483e" />
                  <stop offset="100%" stopColor="#102a2d" />
                </linearGradient>
                <radialGradient id="centerGradient" cx="50%" cy="42%" r="64%">
                  <stop offset="0%" stopColor="#fbe68a" />
                  <stop offset="100%" stopColor="#bd612d" />
                </radialGradient>
                <filter id="flowerShadow" x="-40%" y="-40%" width="180%" height="190%">
                  <feDropShadow dx="0" dy="12" stdDeviation="10" floodColor="#080715" floodOpacity="0.48" />
                </filter>
              </defs>

              <g className="botanical-backdrop" filter="url(#flowerShadow)">
                <path className="stem" d="M200 432 C199 375 205 304 200 205" />
                <path className="leaf leaf-left" d="M202 354 C166 323 121 321 78 350 C118 383 164 376 202 354 Z" />
                <path className="leaf-vein leaf-vein-left" d="M195 355 C158 351 123 349 87 351" />
                <path className="leaf leaf-right" d="M201 328 C241 298 283 297 326 318 C291 356 244 354 201 328 Z" />
                <path className="leaf-vein leaf-vein-right" d="M208 329 C249 324 284 320 317 320" />
              </g>

              <g className="petal petal-one" transform="rotate(0 200 190)">
                <path d="M200 190 C171 154 148 91 173 45 C187 17 218 24 226 53 C238 98 223 153 209 190 Z" fill="url(#petalGradient)" />
                <path className="petal-shine" d="M199 181 C198 134 192 88 181 54" />
                <path className="petal-vein" d="M204 184 C204 137 209 98 218 65" />
              </g>
              <g className="petal petal-two" transform="rotate(60 200 190)">
                <path d="M200 190 C171 154 148 91 173 45 C187 17 218 24 226 53 C238 98 223 153 209 190 Z" fill="url(#petalGradient)" />
                <path className="petal-shine" d="M199 181 C198 134 192 88 181 54" />
                <path className="petal-vein" d="M204 184 C204 137 209 98 218 65" />
              </g>
              <g className="petal petal-three" transform="rotate(120 200 190)">
                <path d="M200 190 C171 154 148 91 173 45 C187 17 218 24 226 53 C238 98 223 153 209 190 Z" fill="url(#petalGradient)" />
                <path className="petal-shine" d="M199 181 C198 134 192 88 181 54" />
                <path className="petal-vein" d="M204 184 C204 137 209 98 218 65" />
              </g>
              <g className="petal petal-four" transform="rotate(180 200 190)">
                <path d="M200 190 C171 154 148 91 173 45 C187 17 218 24 226 53 C238 98 223 153 209 190 Z" fill="url(#petalGradient)" />
                <path className="petal-shine" d="M199 181 C198 134 192 88 181 54" />
                <path className="petal-vein" d="M204 184 C204 137 209 98 218 65" />
              </g>
              <g className="petal petal-five" transform="rotate(240 200 190)">
                <path d="M200 190 C171 154 148 91 173 45 C187 17 218 24 226 53 C238 98 223 153 209 190 Z" fill="url(#petalGradient)" />
                <path className="petal-shine" d="M199 181 C198 134 192 88 181 54" />
                <path className="petal-vein" d="M204 184 C204 137 209 98 218 65" />
              </g>
              <g className="petal petal-six" transform="rotate(300 200 190)">
                <path d="M200 190 C171 154 148 91 173 45 C187 17 218 24 226 53 C238 98 223 153 209 190 Z" fill="url(#petalGradient)" />
                <path className="petal-shine" d="M199 181 C198 134 192 88 181 54" />
                <path className="petal-vein" d="M204 184 C204 137 209 98 218 65" />
              </g>

              <g className="flower-center">
                <circle className="center-shadow" cx="200" cy="190" r="47" />
                <circle className="center-disc" cx="200" cy="190" r="35" fill="url(#centerGradient)" />
                <g className="stamens">
                  <path d="M200 190 L200 137" />
                  <path d="M200 190 L225 143" />
                  <path d="M200 190 L248 172" />
                  <path d="M200 190 L242 215" />
                  <path d="M200 190 L218 237" />
                  <path d="M200 190 L182 237" />
                  <path d="M200 190 L158 215" />
                  <path d="M200 190 L152 171" />
                  <path d="M200 190 L175 143" />
                </g>
                <g className="anthers">
                  <circle cx="200" cy="134" r="5" />
                  <circle cx="227" cy="141" r="5" />
                  <circle cx="250" cy="170" r="5" />
                  <circle cx="244" cy="217" r="5" />
                  <circle cx="220" cy="240" r="5" />
                  <circle cx="180" cy="240" r="5" />
                  <circle cx="156" cy="217" r="5" />
                  <circle cx="150" cy="170" r="5" />
                  <circle cx="173" cy="141" r="5" />
                </g>
                <circle className="pistil" cx="200" cy="190" r="8" />
              </g>
            </svg>
          </div>
          <div className="flower-label flower-label-bottom">crescer • abrir • amar</div>
        </div>
      </section>

      <footer className="site-footer">
        <span>feito para durar mais do que um instante</span>
        <span className="footer-mark">♡</span>
        <span>com amor, sempre</span>
      </footer>
    </main>
  );
}
